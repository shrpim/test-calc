public class ScannerException extends Exception{
    public ScannerException(String description){
        System.out.println(description);;
    }
}
